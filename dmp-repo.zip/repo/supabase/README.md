# supabase/

Migration-first. Every schema change — table, column, index, constraint, view,
function, policy — exists as a numbered SQL file here and is applied through the
migration tool. **Never typed into the dashboard.** A schema that lives only in the
dashboard cannot be reviewed, reverted, or recreated, and at ~48 tables that becomes
unrecoverable fast.

```
migrations/
  0001_initial_schema.sql   Your 28-table seed schema, copied verbatim from
                            legacy/seed/schema_supabase.sql. STAGED, NOT APPLIED.
                            Prompt 0026 applies it. Do not edit it — it has already
                            been parse-validated and passed 72 integrity checks.
seed/                       CSV import harness (Prompt 0028)
functions/                  Edge functions — the ported simulation (Phase 6)
```

## Import order for the 28 seed CSVs (Prompts 0029–0036)

Not cosmetic. `teams` must precede `owners` and `stadiums`; both carry foreign keys
back to it.

```
league_conferences, league_divisions, teams, owners, stadiums, colleges,
coaches, coach_attributes, team_coaching_staff, team_schemes,
players, player_attributes, player_contracts, player_morale, player_traits,
player_injuries, team_rosters, team_depth_charts, season_schedule,
team_bye_weeks, free_agents, draft_picks, draft_classes, franchise_finances,
salary_cap, team_needs, owner_goals, data_provenance
```

## Missing runtime layer

This schema describes the **starting world only**. Searching it for save, user, auth
or policy returns zero matches. Save slots, calendar state, results, box scores,
standings, season statistics, season grades, awards, honours, records, transactions,
news, in-game draft classes and scouting do not exist yet. They are specified in
Prompt 0038 and created in Prompts 0039–0041.
