// Domain model index.
//
// NOTE: this schema describes the STARTING WORLD only. The tables required for a
// running game — save state, calendar, results, standings, season statistics,
// season grades, awards, honours, records, transactions and news — do NOT exist
// yet. They are specified and created in Phase 2 (Prompts 0038-0042).

export * from './league';
export * from './teams';
export * from './coaches';
export * from './players';
export * from './playerAttributes';
export * from './contracts';
export * from './roster';
export * from './schedule';
export * from './draft';
export * from './meta';

export * from './competition';

/** Every table declared in schema_supabase.sql. Used to prevent typo-driven
 *  duplicate tables — a name not in this union is not a real table. */
export type TableName =
  | 'coach_attributes'
  | 'coaches'
  | 'colleges'
  | 'data_provenance'
  | 'draft_classes'
  | 'draft_picks'
  | 'franchise_finances'
  | 'free_agents'
  | 'league_conferences'
  | 'league_divisions'
  | 'owner_goals'
  | 'owners'
  | 'player_attributes'
  | 'player_contracts'
  | 'player_injuries'
  | 'player_morale'
  | 'player_traits'
  | 'players'
  | 'salary_cap'
  | 'season_schedule'
  | 'stadiums'
  | 'team_bye_weeks'
  | 'team_coaching_staff'
  | 'team_depth_charts'
  | 'team_needs'
  | 'team_rosters'
  | 'team_schemes'
  | 'teams';

export const TABLE_NAMES: readonly TableName[] = [
  'coach_attributes',
  'coaches',
  'colleges',
  'data_provenance',
  'draft_classes',
  'draft_picks',
  'franchise_finances',
  'free_agents',
  'league_conferences',
  'league_divisions',
  'owner_goals',
  'owners',
  'player_attributes',
  'player_contracts',
  'player_injuries',
  'player_morale',
  'player_traits',
  'players',
  'salary_cap',
  'season_schedule',
  'stadiums',
  'team_bye_weeks',
  'team_coaching_staff',
  'team_depth_charts',
  'team_needs',
  'team_rosters',
  'team_schemes',
  'teams',
] as const;
